import work.Pippo

def pippo = new Pippo()

return ['peppe': pippo.getStr('peppe')]