package work

class Pippo {

    String getStr(String inStr) {
        return inStr
    }
}